function [f,g] = softmax_regression_vec(theta, X, y)
  %
  % Arguments:
  %   theta - A vector containing the parameter values to optimize.
  %       In minFunc, theta is reshaped to a long vector.  So we need to
  %       resize it to an n-by-(num_classes-1) matrix.
  %       Recall that we assume theta(:,num_classes) = 0.
  %
  %   X - The examples stored in a matrix.  
  %       X(i,j) is the i'th coordinate of the j'th example.
  %   y - The label for each example.  y(j) is the j'th example's label.
  %   f is the cost while g is the gradient
  
  m=size(X,2);%m=60000, the number of training samples
  n=size(X,1);%n=785, the number of features

  % theta is a vector;  need to reshape to n x num_classes.
  theta=reshape(theta, n, []); %now theta is 785*9

  y_hat = exp(theta' * X); % (K - 1) * m
  y_hat = [y_hat; ones(1, size(y_hat, 2))]; % K * m, the last row is all ones

  y_hat_sum = sum(y_hat, 1); % 1 * m
  p_y = bsxfun(@rdivide, y_hat, y_hat_sum); % K * m
  A = log(p_y); % K * m
  index = sub2ind(size(y_hat), y, 1 : size(y_hat, 2));
  f = -sum(A(index));

  indicator = zeros(size(p_y)); % K * m
  indicator(index) = 1;
  g = -X * (indicator - p_y)'; % K * n

  g=g(:, 1:end - 1); 
  g = g(:); % make gradient a vector for minFunc
