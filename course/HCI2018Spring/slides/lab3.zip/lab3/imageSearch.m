function bestImage = imageSearch(queryImage, numberOfResults)
% For test: 
% queryImage = imread('airplane_test.jpg');
% imageSearch(queryImage, 5)

load('savedImageIndex.mat'); % database for searching

[imageIDs, scores] = retrieveImages(queryImage, imageIndex); % search database using the query image

resultsCount = length(imageIDs);
if resultsCount>=numberOfResults
    bestMatch  = imageIDs(1:numberOfResults);
end

for i = 1:length(bestMatch)
    bestImage = imageIndex.ImageLocation{bestMatch(i)};
    figure;
    imshow(bestImage);
end
